$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$project = Join-Path $root "DotaChaos.csproj"
$plugins = Join-Path $root "BepInEx\plugins\DotaChaos"

dotnet build $project -c Release

$dll = Join-Path $root "bin\Release\netstandard2.1\DotaChaos.dll"
if (!(Test-Path $dll)) {
    throw "Build completed but DotaChaos.dll was not found at $dll"
}

New-Item -ItemType Directory -Force -Path $plugins | Out-Null
Copy-Item $dll (Join-Path $plugins "DotaChaos.dll") -Force

Write-Host ""
Write-Host "Built: $dll"
Write-Host "Installed to: $plugins\DotaChaos.dll"
