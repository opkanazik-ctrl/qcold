# Dota Chaos — PEAK prototype 0.1.0

## Install target

Copy the built `DotaChaos.dll` to:

`PEAK/BepInEx/plugins/DotaChaos/DotaChaos.dll`

The source package itself mirrors that destination under `src/`.

## Build

Requirements:
- Windows
- .NET SDK capable of building `netstandard2.1`
- PEAK + BepInEx installed
- The `lib/` references from this package

Run:

`build.ps1`

The script copies the resulting DLL to:
`BepInEx/plugins/DotaChaos/`

## What this prototype does

It keeps normal PEAK gameplay and periodically injects Dota-inspired chaos:
random Blink, Haste, extra-jump, Toss, Vacuum, Rupture, Low Gravity,
Arcane Surge, Tiny Throw and Chronosphere-like events.

It also creates simple local prototype creeps.

## Important

This is a mechanics prototype, not a Dota 2 client mod.
It does not inject into or alter Dota 2 and does not bypass anti-cheat.

The current prototype is intentionally local/client-side. Do not publish it as
fully synchronized multiplayer until it has been tested with two PEAK instances
and the network-authority path has been implemented.
